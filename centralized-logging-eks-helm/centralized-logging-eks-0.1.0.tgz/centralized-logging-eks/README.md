# centralized-logging-eks Helm chart

A single umbrella Helm chart for a production-style centralized logging platform on Amazon EKS:

```text
Kubernetes Pods
  -> Fluent Bit DaemonSet
  -> Apache Kafka / Strimzi
  -> Vector Aggregator StatefulSet
  -> Elasticsearch hot/warm data nodes + Amazon S3 archive
  -> Kibana + ElastAlert
```

## Suggested release name

Use this release name:

```bash
platform-logging
```

It is short, clear, and works well with generated resource names such as:

```text
platform-logging-kafka
platform-logging-es
platform-logging-vector
platform-logging-kibana
```

## Install

```bash
helm dependency update ./centralized-logging-eks

helm upgrade --install platform-logging ./centralized-logging-eks \
  --namespace logging \
  --create-namespace \
  -f ./centralized-logging-eks/values-eks-production.yaml \
  --wait \
  --timeout 30m
```

## Upgrade

```bash
helm dependency update ./centralized-logging-eks

helm upgrade platform-logging ./centralized-logging-eks \
  --namespace logging \
  -f ./centralized-logging-eks/values-eks-production.yaml \
  --wait \
  --timeout 30m
```

## Uninstall

```bash
helm uninstall platform-logging -n logging
```

Persistent volumes and S3 data may remain depending on your StorageClass and chart values.

## Important CRD/operator note

This chart can install the Strimzi and ECK operators as dependencies. For mature production environments, many platform teams prefer installing operators separately and then setting:

```yaml
operators:
  strimzi:
    enabled: false
  eck:
    enabled: false
```

The application resources remain fully managed by this Helm release either way.

## EKS storage

The default StorageClass is `gp3`. Change these values if your EKS cluster uses a different StorageClass:

```yaml
kafka.controllers.storageClassName
kafka.brokers.storageClassName
elasticsearch.masters.storageClassName
elasticsearch.hotData.storageClassName
elasticsearch.warmData.storageClassName
vector.pvc.storageClassName
```

## S3 authentication options

### Recommended for EKS: IRSA

```yaml
s3:
  authMode: irsa
  serviceAccountAnnotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::<account-id>:role/platform-logging-vector-s3
```

### Secret-based auth

```yaml
s3:
  authMode: secret
  createSecret: true
  accessKeyId: "..."
  secretAccessKey: "..."
```

Or use an existing secret:

```yaml
s3:
  authMode: secret
  createSecret: false
  existingSecret: logging-s3-archive
```

The existing secret must contain:

```text
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_REGION
AWS_S3_BUCKET
```

## Kibana

Port-forward:

```bash
kubectl port-forward -n logging svc/platform-logging-kibana-kb-http 5601:5601
```

Open:

```text
https://localhost:5601
```

Password:

```bash
kubectl get secret platform-logging-es-es-elastic-user \
  -n logging \
  -o go-template='{{.data.elastic | base64decode}}{{"\n"}}'
```

Create a Kibana data view:

```text
kubernetes-logs-*
```

## Default production starter sizing

| Component | Default |
|---|---:|
| Kafka controllers | 3 |
| Kafka brokers | 5 |
| Kafka topic partitions | 96 |
| Elasticsearch master nodes | 3 |
| Elasticsearch hot data nodes | 6 |
| Elasticsearch warm data nodes | 3 |
| Vector aggregators | 6 |
| Kibana replicas | 2 |
| ElastAlert replicas | 2 |
| Fluent Bit | 1 pod per node |

## App logging standard

Each team should log structured JSON to stdout/stderr:

```json
{
  "timestamp": "2026-05-13T10:00:00Z",
  "level": "info",
  "message": "order created",
  "trace_id": "abc123",
  "span_id": "def456",
  "service": "order-service",
  "team": "payments",
  "environment": "prod"
}
```

Recommended labels:

```yaml
metadata:
  labels:
    app.kubernetes.io/name: order-service
    app.kubernetes.io/team: payments
    environment: prod
```

## Render locally

```bash
helm template platform-logging ./centralized-logging-eks \
  --namespace logging \
  -f ./centralized-logging-eks/values-eks-production.yaml > rendered.yaml
```
